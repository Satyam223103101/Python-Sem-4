num1=input("enter the first no:")
num2=input("enter the second no:")
sum=float(num1)+float(num2)
print("addition of {0} and {1} is {2}".format(num1,num2,sum))
multi=float(num1)*float(num2)
print("multiplication of {0} and {1} is {2}".format(num1,num2,multi))
div=float(num1)/float(num2)
print("division of {0} and {1} is {2}".format(num1,num2,div))
sub=float(num1)/float(num2)
print("substraction of {0} and {1} is {2}".format(num1,num2,sub))
power=float(num1)**float(num2)
print("power of {0} and {1} is {2}".format(num1,num2,power))
floar=float(num1)//float(num2)
print("floar of {0} and {1} is {2}".format(num1,num2,floar))
mod=float(num1)%float(num2)
print("modulo of {0} and {1} is {2}".format(num1,num2,mod))
if num1>num2:
 print("{0} is greter than {1}".format(num1,num2))
else:
 print("{1} is greter than {0}".format(num1,num2))
count=0
while(count<=5):
 count=count+1
 print("my name is satyam")
